async function cargarPaises() {
    const ul = document.getElementById('listaPaises');
    ul.innerHTML = 'Cargando...';
    try {
        const respuesta = await fetch('https://restcountries.com/v3.1/all');
        const paises = await respuesta.json();

        ul.innerHTML = '';
        paises.slice(0, 5).forEach(pais => {
            const li = document.createElement('li');
            li.textContent = `${pais.name.common} - Capital: ${pais.capital?.[0] ?? 'No tiene'} - Región: ${pais.region} - Subregión: ${pais.subregion ?? 'No tiene'} - Población: ${pais.population.toLocaleString()}`;
            ul.appendChild(li);
        });
    } catch (error) {
        ul.innerHTML = 'Error al cargar países';
        console.error(error);
    }
}
