async function cargarTriviaMath() {
    const p = document.getElementById('trivia');
    p.innerHTML = 'Cargando trivia...';
    try {
        const res = await fetch('http://numbersapi.com/random/math?json');
        const info = await res.json();
        p.innerHTML = `${info.text} (Número: ${info.number} - Tipo: ${info.type}) - ${info.found ? 'Hecho' : 'No encontrado'}`;
    } catch (error) {
        p.innerHTML = 'Error al cargar trivia';
        console.error(error);
    }
}