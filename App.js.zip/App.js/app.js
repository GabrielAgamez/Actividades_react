async function cargarUsuarios() {
    const ul = document.getElementById('listaUsuarios');
    ul.innerHTML = 'Cargando...';

    try {
        const respuesta = await fetch('https://jsonplaceholder.typicode.com/users');
        const usuarios = await respuesta.json();

        const usuariosFiltrados = usuarios.slice(4, 6);

        ul.innerHTML = '';
        usuariosFiltrados.forEach(usuario => {
            const li = document.createElement('li');
            li.textContent = `${usuario.name} - ${usuario.email} - ${usuario.phone} - ${usuario.website} - ${usuario.company.name} - ${usuario.address.city}`;
            ul.appendChild(li);
        });
    } catch (error) {
        ul.innerHTML = 'Error al cargar usuarios';
        console.error(error);
    }
}
