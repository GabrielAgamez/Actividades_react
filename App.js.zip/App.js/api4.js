async function cargarClimaMedellin() {
    const div = document.getElementById('clima');
    div.innerHTML = 'Cargando clima en Medellín...';

    const lat = 6.2442;
    const lon = -75.5812;

    try {
        const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
        const data = await res.json();
        const clima = data.current_weather;
        div.innerHTML = `Clima en Medellín: ${clima.temperature}°C - Viento: ${clima.windspeed} km/h - Hora: ${clima.time}`;
    } catch (error) {
        div.innerHTML = 'Error al cargar clima';
        console.error(error);
    }
}
